namespace PhoneProject.IRingableClass
{
    public interface IRingable
    {
        // your code here
        string Ring ();
        string Unlock ();
    }
}